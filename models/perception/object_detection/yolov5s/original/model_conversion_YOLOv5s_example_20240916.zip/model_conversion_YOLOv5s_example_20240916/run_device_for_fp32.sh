#!/bin/sh
input_dir="evaluation_dataset_fp32"
output_dir="device_outputs_fp32"

# Run inference and save the three outputs to output_dir
run_eval() {
    echo Running "$1"
    out0="$output_dir/$(basename "$1" .bin)_0.bin"
    out1="$output_dir/$(basename "$1" .bin)_1.bin"
    out2="$output_dir/$(basename "$1" .bin)_2.bin"
    /usr/sbin/neuronrt -m hw -a yolov5s_mtk.dla -i "$1" -o "$out0" -o "$out1" -o "$out2"
}

# Loop through all input data in evaluation dataset
for input_bin in "$input_dir"/*; do
    if [ -f "$input_bin" ]; then
        run_eval "$input_bin"
    fi
done