import os
import numpy as np
from utils.dataloaders import LoadImagesAndLabels
from utils.general import check_dataset
import mtk_converter

# Create TFLite parser
parser = mtk_converter.TFLiteParser('yolov5s_mtk.tflite')
# Get the first input details since the model has only one input
input_details = parser.get_input_tensor_details()[0]

data = 'data/coco128.yaml'
eval_dir = 'evaluation_dataset_fp32'
os.makedirs(eval_dir)

# Save the evaluation dataset as binary file
dataset = LoadImagesAndLabels(check_dataset(data)['val'], batch_size=1)

for idx, (im, _target, _path, _shape) in enumerate(dataset):
    # Expand shape from (3, 640, 640) to (1, 3, 640, 640)
    im = np.expand_dims(im, axis=0).astype(np.float32)
    # 0 - 255 to 0.0 - 1.0
    im /= 255
    # Save as binary file
    im.tofile(os.path.join(eval_dir, 'batch-{:05d}.bin'.format(idx)))